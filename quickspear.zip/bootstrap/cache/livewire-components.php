<?php return array (
  'notifications' => 'App\\Http\\Livewire\\Notifications',
  'notifications-count' => 'App\\Http\\Livewire\\NotificationsCount',
  'shipment-all' => 'App\\Http\\Livewire\\ShipmentAll',
);