<?php $__env->startSection('title', 'الرئيسية'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-sm-12">
	    <div class="card">
	      <div class="card-header">
	        <h5>المدن</h5>
	      </div>
	      <div class="card-body">
	        <div class="table-responsive">
	          <table class="display" id="basic-1">
	            <thead>
	              <tr>
	                <th>#</th>
	                <th>الاسم</th>
	                <th>العمليات</th>
	              </tr>
	            </thead>
	              <tbody>
	              	<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <tr>
		                <td><?php echo e($loop->iteration); ?></td>
		                <td><?php echo e($city->name); ?></td>
		                <td>
		                	<a class="btn btn-primary" href="<?php echo e(route('admin.cities.edit', $city->id)); ?>"><i class="fa fa-edit"></i></a>
                            <a class="btn btn-info" href="<?php echo e(route('admin.cities.rates', $city->id)); ?>">اسعار الشحن</a>
		                	
                                <a class="btn btn-info" href="javascript:void(0)"  onclick="return confirm('Are you sure of deleting this city ?') ? document.getElementById('delete-city-<?php echo e($city->id); ?>').submit() : '';"><i class="fa fa-trash"></i></a>
                            <form action="<?php echo e(route('admin.cities.destroy', $city->id)); ?>" method="post" class="d-none"
                                id="delete-city-<?php echo e($city->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form> 
		                </td>
		            </tr>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	          	  </tbody>
	          </table>
	        </div>
	      </div>
	    </div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/admin/cities/index.blade.php ENDPATH**/ ?>