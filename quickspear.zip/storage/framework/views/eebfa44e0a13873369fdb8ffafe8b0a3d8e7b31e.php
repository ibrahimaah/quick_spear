<?php $__env->startSection('active1', 'active'); ?>
<?php $__env->startSection('accountContent'); ?>
<h2 class="mb-4"><?php echo e(__('Account Details')); ?></h2>
<div class="card">
    <?php if(auth('team')->check()): ?>
    <form action="<?php echo e(route('front.user.account_update')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card-header">
            <h4><?php echo e(__('Account Informations')); ?></h4>
        </div>
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Account Number')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth('team')->user()->team->ACCOUNT_NUMBER()); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Country')); ?></label>
                        <p class="card-text">
                            <?php echo e(__('Jordan')); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Currency')); ?></label>
                        <p class="card-text">
                            JOD
                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Account Type')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth('team')->user()->team->type ?? ''); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Phone')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth('team')->user()->team->phone); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Email Address')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth('team')->user()->team->email); ?>

                        </p>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Name')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth('team')->user()->team->name); ?>"
                            name="name" />
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Phone')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth('team')->user()->team->phone); ?>"
                            name="phone" />
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Email Address')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth('team')->user()->team->email); ?>"
                            name="email" />
                    </div>
                </div>
            </div>
        </div>
        <div class="card-header">
            <button class="btn btn-primary" type="submit"><?php echo e(__('Apply')); ?></button>
        </div>
    </form>
    <?php else: ?>
    <form action="<?php echo e(route('front.user.account_update')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card-header">
            <h4><?php echo e(__('Account Informations')); ?></h4>
        </div>
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Account Number')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth()->user()->ACCOUNT_NUMBER()); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Country')); ?></label>
                        <p class="card-text">
                            <?php echo e(__('Jordan')); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Currency')); ?></label>
                        <p class="card-text">
                            JOD
                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Account Type')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth()->user()->type ?? ''); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Phone')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth()->user()->phone); ?>

                        </p>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Email Address')); ?></label>
                        <p class="card-text">
                            <?php echo e(auth()->user()->email); ?>

                        </p>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Name')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->name); ?>"
                            name="name" />
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Phone')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->phone); ?>"
                            name="phone" />
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Email Address')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->email); ?>"
                            name="email" />
                    </div>
                </div>
            </div>
        </div>
        <div class="card-header">
            <button class="btn btn-primary" type="submit"><?php echo e(__('Apply')); ?></button>
        </div>
    </form>
    <?php endif; ?>
</div>
<br />
<hr />
<br />
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5><?php echo e(__('Editing Orders')); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm display" id="basic-1">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Created.')); ?></th>
                                <th><?php echo e(__('Type')); ?></th>
                                <th><?php echo e(__('Description')); ?></th>
                                <th><?php echo e(__('Action Status')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $editOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($order->created_at->format('Y - m - d')); ?></td>
                                <td><?php echo e($order->type); ?></td>
                                <td><?php echo $order->desc; ?></td>
                                <td><?php echo e($order->status); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.account.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/account/account-details.blade.php ENDPATH**/ ?>