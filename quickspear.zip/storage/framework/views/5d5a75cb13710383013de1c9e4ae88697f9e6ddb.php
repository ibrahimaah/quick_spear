<?php $__env->startSection('active6', 'active'); ?>
<?php $__env->startSection('accountContent'); ?>
    <h2 class="mb-4"><?php echo e(__('Address')); ?></h2>
    <div class="card">
        <?php if(session()->has('error')): ?>
            <div class="alert text-center py-4 my-3 alert-danger"><?php echo e(session()->get('error')); ?></div>
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
            <div class="alert text-center py-4 my-3 alert-success"><?php echo e(session()->get('success')); ?></div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="card-header">
            <h4><?php echo e(__('Add')); ?></h4>
        </div>
        <div class="card-body">
            <div class="container">
                <form action="<?php echo e(route('front.user.address_store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12 my-2 col-md-4">
                            <label><?php echo e(__('Name')); ?></label><span class="text-danger"> * </span>
                            <input class="form-control mt-2 ml-2" value="<?php echo e(old('name')); ?>" type="text"
                                name="name" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 my-2 col-md-4">
                            <label><?php echo e(__('Phone')); ?></label><span class="text-danger"> * </span>
                            <input class="form-control mt-2 ml-2" value="<?php echo e(old('phone')); ?>" type="text"
                                name="phone" />
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 my-2 col-md-4">
                            <label><?php echo e(__('City')); ?></label><span class="text-danger">*</span>
                            <select class="form-control mt-2 ml-2" type="text" name="city">
                                <?php $__currentLoopData = App\Models\City::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 my-2 col-md-4">
                            <label><?php echo e(__('Region')); ?></label><span class="text-danger"> * </span>
                            <input class="form-control mt-2 ml-2" value="<?php echo e(old('region')); ?>" type="text"
                                name="region" />
                            <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 my-2 col-md-4">
                            <label><?php echo e(__('Description')); ?></label><span class="text-danger"> * </span>
                            <input class="form-control mt-2 ml-2" value="<?php echo e(old('desc')); ?>" type="text"
                                name="desc" />
                            <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="card-header">
                        <button class="btn btn-primary" type="submit"><?php echo e(__('Add')); ?></button>
                    </div>
                </form>
                <hr />
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h5><?php echo e(__('Address')); ?></h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm display" id="basic-1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th><?php echo e(__('Name')); ?></th>
                                                <th><?php echo e(__('Phone')); ?></th>
                                                <th><?php echo e(__('City')); ?></th>
                                                <th><?php echo e(__('Region')); ?></th>
                                                <th><?php echo e(__('Description')); ?></th>
                                                <th><?php echo e(__('Actions')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $addresses->where('type', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($address->name); ?></td>
                                                    <td><?php echo e($address->phone); ?></td>
                                                    <td><?php echo e(App\Models\City::where('id', $address->city)->first()->name ?? $address->city); ?>

                                                    </td>
                                                    <td><?php echo e($address->region); ?></td>
                                                    <td><?php echo e($address->desc); ?></td>
                                                    <td>
                                                        <a class="btn btn-danger btn-sm"
                                                            href="<?php echo e(route('front.user.address_delete', $address->id)); ?>">
                                                            <i class="bi bi-trash"></i>
                                                            <?php echo e(__('Delete')); ?>

                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.account.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/account/address.blade.php ENDPATH**/ ?>