<?php $__env->startSection('content'); ?>
    <section class="container-fluid pt-4">
        <div class="row justify-content-center px-4 pt-0">
            <div class="col-lg-4">
                <div class="section-title">
                    <h2>إنشاء حساب جديد</h2>
                </div>
                <form action="<?php echo e(route('front.register')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <input type="text" data-toggle="tooltip" data-placement="top" title="الاسم يجب ان يكون اكبر من 8 حروف واقل من 30 " name="name" value="<?php echo e(old('name')); ?>" class="form-control py-3 mb-2" id="name" placeholder="الإسم الكامل" required />
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger text-center"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <span>الاسم يجب ان يكون اكبر من 8 حروف واقل من 30</span>

                    </div>
                    <div class="form-group mt-2 row">
                        <input type="text" value="<?php echo e(old('phone')); ?>" class="form-control py-3" name="phone" id="phone" placeholder="رقم الهاتف" required />
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger text-center"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mt-3 row">
                        <input type="text" value="<?php echo e(old('email')); ?>" class="form-control py-3" name="email" id="email" placeholder="البريد الالكتروني" required autocomplete="false" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger text-center"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mt-3 row">
                        <input type="password" value="<?php echo e(old('password')); ?>" class="form-control py-3" name="password" id="password" placeholder="كلمة المرور" required autocomplete="new-password" />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger text-center"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mt-3 row">
                        <input type="password" value="<?php echo e(old('password_confirmation')); ?>" class="form-control py-3" name="password_confirmation" id="password_confirmation" placeholder="اعادة كتابة كلمة المرور" required autocomplete="new-password" />
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger text-center"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="text-center mt-3 row">
                        <button type="submit" class="btn btn-block btn-sm btn py-3
                         btn-primary">إنشاء حساب جديد</button>
                    </div>
                </form>
            </div>
            
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/auth/register.blade.php ENDPATH**/ ?>