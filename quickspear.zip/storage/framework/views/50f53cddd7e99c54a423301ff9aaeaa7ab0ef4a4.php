<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />

    <title>Ship</title>
    <meta content="" name="description" />
    <meta content="" name="keywords" />

    <!-- Favicons -->
    <link href="<?php echo e(asset(App\Models\Setting::first()->website_logo ?? 'assets/images/logo/logo.png')); ?>"
        rel="icon" />
    <link href="<?php echo e(asset(App\Models\Setting::first()->website_logo ?? 'assets/images/logo/logo.png')); ?>"
        rel="apple-touch-icon" />

    <!-- Google Fonts -->

    <!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet"> -->

    <!-- Vendor CSS Files -->
    
    <link href="<?php echo e(asset('assets')); ?>/vendor/bootstrap/css/bootstrap<?php echo e(app()->getLocale() === 'ar' ? '.rtl' : ''); ?>.css"
        rel="stylesheet">
    <link href="<?php echo e(asset('assets')); ?>/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/vendor/boxicons/css/boxicons.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/vendor/glightbox/css/glightbox.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />

    <!-- Template Main CSS File -->

    <link href="<?php echo e(asset('assets')); ?>/css/style.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@500&display=swap" rel="stylesheet" />

</head>

<body>
    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center p-3">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <div class="logo mx-4">
                <a href="/"><img
                        src="<?php echo e(asset(App\Models\Setting::first()->website_logo ?? 'assets/images/logo/logo.png')); ?>"
                        alt="" class="img-fluid"></a>
            </div>

            <nav id="navbar" class="navbar justify-content-between">
                <i class="bi bi-list mobile-nav-toggle"></i>
                <ul class="justify-content-between">
                    <li><a class="nav-link mx-1 scrollto"
                            href="<?php echo e(route('front.express.index')); ?>"><?php echo e(__('Shipping')); ?></a></li>
                    <li><a class="nav-link mx-1 scrollto"
                            href="<?php echo e(route('front.payments.index')); ?>"><?php echo e(__('Payments')); ?></a></li>
                    <li><a class="nav-link mx-1 scrollto"
                            href="<?php echo e(route('front.user.account')); ?>"><?php echo e(__('Account')); ?></a></li>
                    <li><a class="nav-link mx-1 scrollto" href="#"><?php echo e(__('Why us ?')); ?></a></li>
                    <li><a class="nav-link mx-1 scrollto"
                            href="<?php echo e(route('front.contact')); ?>"><?php echo e(__('Contact us')); ?></a></li>
                    <?php
                        use Mcamara\LaravelLocalization\LaravelLocalization;
                        $loc = new LaravelLocalization();
                    ?>
                    <li><a class="nav-link mx-1 scrollto"
                            href="<?php echo e(app()->getLocale() == 'ar' ? $loc->getLocalizedURL('en') : $loc->getLocalizedURL('ar')); ?>"><?php echo e(app()->getLocale() == 'en' ? 'عربي' : 'English'); ?></a>
                    </li>
                </ul>
            </nav>
            <!-- .navbar -->
            <nav id="navbar" class="navbar order-last order-lg-0">
                <?php if(auth()->check() || auth('team')->check()): ?>
                    <div class="nav-item dropdown container d-flex align-items-center justify-content-end">
                        <a href="#">
                            <span class="mx-2"><?php echo e(auth()->user()->name ?? auth('team')->user()->name); ?></span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul>
                            <li><a href="<?php echo e(route('front.user.account')); ?>"><?php echo e(__('Profile')); ?></a></li>
                            <li><a href="<?php echo e(route('front.user.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                            <li><a href="<?php echo e(route('front.logout')); ?>"><?php echo e(__('Logout')); ?></a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('front.get_register')); ?>"
                        class="btn btn-outline-primary px-3 py-2 mx-3"><?php echo e(__('Register')); ?></a>
                    <a href="<?php echo e(route('front.get_login')); ?>"
                        class="btn btn-outline-primary px-3 py-2"><?php echo e(__('Log In')); ?></a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <!-- End Header -->
    <main id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                </div>
            </div>
        </div>


        <div class="container d-md-flex py-4">
            <div class="me-md-auto text-center text-md-start">
                <div class="copyright">
                    &copy; Copyright <strong><span>MetaForTech</span></strong>. All Rights Reserved
                </div>
            </div>
            
        </div>
    </footer>
    <!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('assets')); ?>/vendor/purecounter/purecounter.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/vendor/waypoints/noframework.waypoints.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('assets')); ?>/js/main.js"></script>
</body>

</html>
<?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/layouts/app.blade.php ENDPATH**/ ?>