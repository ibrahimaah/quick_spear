<?php $__env->startSection('title', 'الرئيسية'); ?>
<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card col-6">
            <div class="card-body">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        إجرائات سريعة
                    </div>
                    <div class="col-12 divider" style="min-height: 2px;"></div>
                </div>
                <div class="col-12 p-3 row d-flex">
                    <div class="col-4  d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.import.create')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                <span class="fa fa-arrow-up fa-3x"></span>
                                <div class="col-12 p-0 text-center">
                                    تحميل شيت شحنات
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.shipments.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                <span class="fa fa-truck fa-3x"></span>
                                <div class="col-12 p-0 text-center">
                                    الشحنات
                                </div>
                            </div>
                        </a>
                    </div>


                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2 card">
                        <a href="<?php echo e(route('admin.requests.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center card-body">
                                <span class="fa fa-edit fa-3x"></span>
                                <div class="col-12 p-0 text-center">
                                    عرض كل طلبات الدفع
                                    منتظر : (<?php echo e(App\Models\PaymentRequest::where('status', 0)->count()); ?>) <br />
                                    تم : (<?php echo e(App\Models\PaymentRequest::where('status', 1)->count()); ?>)
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/admin/home.blade.php ENDPATH**/ ?>