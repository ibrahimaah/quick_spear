<?php $__env->startSection('title', 'المستخدمين'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-sm-12">
	    <div class="card">
	      <div class="card-header">
	        <h5>المستخدمين</h5>
	      </div>
	      <div class="card-body">
	        <div class="table-responsive">
	          <table class="table table-sm display" id="basic-1">
	            <thead>
	              <tr>
	                <th>#</th>
	                <th>رقم الحساب</th>
	                <th>الاسم</th>
	                <th>رقم الهاتف</th>
	                <th>البريد الالكتروني</th>
	                <th>العمليات</th>
	              </tr>
	            </thead>
	              <tbody>
	              	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <tr>
		                <td><?php echo e($loop->iteration); ?></td>
		                <td><?php echo e($user->ACCOUNT_NUMBER()); ?></td>
		                <td><?php echo e($user->name); ?></td>
		                <td><?php echo e($user->phone); ?></td>
		                <td><?php echo e($user->email); ?></td>
		                <td>
		                	<a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.users.edit', $user->id)); ?>"><i class="fa fa-edit"></i> تعديل</a>
		                	<a class="btn btn-info btn-sm" href="<?php echo e(route('admin.users.show', $user->id)); ?>"><i class="fa fa-eye"></i> عرض</a>
		                	<a class="btn btn-danger btn-sm" href="javascript:void(0)" onclick="confirm('Are you sure deleting user ?') ? document.getElementById('del<?php echo e($user->id); ?>').submit() : '' ;"><i class="fa fa-trash"></i> حذف</a>
							<form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="post" id="del<?php echo e($user->id); ?>" style="display: none;">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							</form>
						</td>
		            </tr>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	          	  </tbody>
	          </table>
	        </div>
	      </div>
	    </div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/admin/users/index.blade.php ENDPATH**/ ?>