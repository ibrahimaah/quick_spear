<!-- footer start-->
        <footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">جميع الحقوق محفوظة <?php echo e(date('Y')); ?> ©  تطوير شركة ميتا فور تيك  </p>
              </div>
            </div>
          </div>
        </footer>
<?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/admin/layouts/inc/footer.blade.php ENDPATH**/ ?>