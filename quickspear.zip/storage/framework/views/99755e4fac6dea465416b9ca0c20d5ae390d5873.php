<?php $__env->startSection('active3', 'active'); ?>
<?php $__env->startSection('accountContent'); ?>
<h2 class="mb-4"><?php echo e(__('Documents')); ?></h2>
<div class="card">
    <?php if(session()->has('error')): ?>
        <div class="alert text-center py-4 my-3 alert-danger"><?php echo e(session()->get('error')); ?></div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert text-center py-4 my-3 alert-success"><?php echo e(session()->get('success')); ?></div>
    <?php endif; ?>
    <?php echo csrf_field(); ?>
    <div class="card-header">
        <h4><?php echo e(__('Add')); ?> <?php echo e(__('Documents')); ?></h4>
    </div>
    <div class="card-body">
        <div class="container">
            <form action="<?php echo e(route('front.user.documents_store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Documents')); ?></label><span class="text-danger"> * </span>
                        <input class="form-control mt-2 ml-2" type="file" name="document" />
                        <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <?php
                            $providers = ['id', 'passport', 'license'];
                        ?>
                        <label><?php echo e(__('Type')); ?></label><span class="text-danger"> * </span>
                        <select class="form-control mt-2 ml-2" name="type">
                            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provider); ?>"><?php echo e($provider); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger text-center p-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="card-header">
                    <button class="btn btn-primary" type="submit"><?php echo e(__('Add')); ?></button>
                </div>
            </form>
            <hr />
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo e(__('Documents')); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(__('Created.')); ?></th>
                                            <th><?php echo e(__('Type')); ?></th>
                                            <th><?php echo e(__('Documents')); ?></th>
                                            <th><?php echo e(__('Action Status')); ?></th>
                                            <th><?php echo e(__('Actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($document->created_at); ?></td>
                                            <td><?php echo e($document->type); ?></td>
                                            <td><img src="<?php echo e(asset($document->document)); ?>" width="150" alt=""></td>
                                            <td>
                                                <?php if($document->statusVerify == 1): ?>
                                                    <span class="badge bg-success"><?php echo e(__('Done.')); ?></span>
                                                <?php elseif($document->statusVerify == 2): ?>
                                                <span class="badge bg-success"><?php echo e(__('Failed to load :resource!')); ?></span>
                                                <?php else: ?>
                                                <span class="badge bg-success"><?php echo e(__('Processing')); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('front.user.documents_delete', $document->id)); ?>">
                                                    <i class="bi bi-trash"></i>
                                                    <?php echo e(__('Delete')); ?>

                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.account.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/account/documents.blade.php ENDPATH**/ ?>