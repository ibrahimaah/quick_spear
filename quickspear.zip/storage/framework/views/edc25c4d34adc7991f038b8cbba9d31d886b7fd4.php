<?php $__env->startSection('title', 'الشحنات'); ?>
<?php $__env->startSection('content'); ?>
    
    <button class="btn btn-success mb-3" type="button" data-bs-toggle="modal"
    data-bs-target="#exampleModal">استيراد اكسيل </button>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="<?php echo e(route('admin.shipment.export')); ?>">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label"><?php echo e(__('Type')); ?></label>
                            <select name="fileType" class="form-control" id="recipient-name">
                                <option value="pdf">pdf</option>
                                <option value="xlsx">xlsx</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('From')); ?></label>
                            <input type="date" name="from" class="form-control" id="message-text">
                        </div>

                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('To')); ?></label>
                            <input type="date" name="to" class="form-control" id="message-text">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('Action Status')); ?></label>
                            <select name="acstatus" class="form-control" id="">
                                <option value=""><?php echo e(__('All')); ?></option>
                                <option value="0"><?php echo e(__('New')); ?></option>
                                <option value="1"><?php echo e(__('Processing')); ?></option>
                                <option value="2"><?php echo e(__('Delivered')); ?></option>
                                <option value="3"><?php echo e(__('Returned')); ?></option>
                                <option value="4"><?php echo e(__('Pending Payments')); ?></option>
                                <option value="5"><?php echo e(__('Payment Successful')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5>الشحنات</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <?php echo e($dataTable->table()); ?>

                        
                        
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts()); ?>

    <?php $__env->stopPush(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/admin/shipments/index.blade.php ENDPATH**/ ?>