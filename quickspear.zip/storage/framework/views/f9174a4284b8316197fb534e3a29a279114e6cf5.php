<div wire:poll>
    <span class="badge rounded-pill badge-secondary"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
</div>
<?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/livewire/notifications-count.blade.php ENDPATH**/ ?>