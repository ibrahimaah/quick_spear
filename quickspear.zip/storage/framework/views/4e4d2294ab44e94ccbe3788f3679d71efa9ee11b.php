<?php $__env->startSection('content'); ?>
    <?php
        // dd($shipment);
    ?>
    <section class="container card mb-5 p-0">
        <div class="col-12 card-header">
            <h4>
                <?php echo e(__('Shipping')); ?> <?php echo e($date_from->format('Y-m-d') . ' - ' . $to->addDays(30)->format('Y-m-d')); ?>

            </h4>

            <button type="button" class="btn btn-success mb-3" data-bs-toggle="modal"
                data-bs-target="#Filter"><?php echo e(__('Filter')); ?></button>

            <div class="modal fade" id="Filter" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="" method="get">
                            <div class="modal-body">
                                
                                <div class="row">
                                    <div class="col-sm-12 col-md-6 mb-3">
                                        <label for="message-text1" class="col-form-label"><?php echo e(__('From')); ?></label>
                                        <input type="date" name="from" class="form-control" id="message-text1">
                                    </div>

                                    <div class="col-sm-12 col-md-6 mb-3">
                                        <label for="message-text" class="col-form-label"><?php echo e(__('To')); ?></label>
                                        <input type="date" name="to" class="form-control" id="message-text">
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"
                                    data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-5">
                <div class="col-md-3">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted"><?php echo e(__('Drafts')); ?></h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                <?php echo e($shipment->where('status', 0)->count()); ?>

                            </h4>
                            <h4 style="font-weight: 700;">
                                <?php if($shipment->count() !== 0): ?>
                                    <?php echo e(number_format(($shipment->where('status', 0)->count() * 100) / $shipment->count(), 2)); ?>

                                    %
                                <?php else: ?>
                                    0 %
                                <?php endif; ?>
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted"><?php echo e(__('Processing')); ?></h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                <?php echo e($shipment->where('status', 1)->count()); ?>

                            </h4>
                            <h4 style="font-weight: 700;">
                                <?php if($shipment->count() !== 0): ?>
                                    <?php echo e(number_format(($shipment->where('status', 1)->count() * 100) / $shipment->count(), 2)); ?>

                                    %
                                <?php else: ?>
                                    0 %
                                <?php endif; ?>
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted"><?php echo e(__('Delivered')); ?></h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                <?php echo e($shipment->whereIn('status', [2, 4])->count()); ?>

                            </h4>
                            <h4 style="font-weight: 700;">
                                <?php if($shipment->count() !== 0): ?>
                                    <?php echo e(number_format(($shipment->whereIn('status', [2, 4])->count() * 100) / $shipment->count(), 2)); ?>

                                    %
                                <?php else: ?>
                                    0 %
                                <?php endif; ?>
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted"><?php echo e(__('Returned')); ?></h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                <?php echo e($shipment->where('status', 3)->count()); ?>

                            </h4>
                            <h4 style="font-weight: 700;">
                                <?php if($shipment->count() !== 0): ?>
                                    <?php echo e(number_format(($shipment->where('status', 3)->count() * 100) / $shipment->count(), 2)); ?>

                                    %
                                <?php else: ?>
                                    0 %
                                <?php endif; ?>
                            </h4>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row mb-5">
                <div id="chart"></div>
            </div>
        </div>
    </section>
    <section class="container card mb-5 p-0">
        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('Payments')); ?></h3>
        </div>
        <div class="card-body">
            <div class="row mb-5">
                <div class="col-md-4">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted"><?php echo e(__('Cash In')); ?></h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                0
                            </h4>
                            <h4 style="font-weight: 700;">
                                0%
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted"><?php echo e(__('Cash Out')); ?></h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                0
                            </h4>
                            <h4 style="font-weight: 700;">
                                0%
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card px-3 py-2">
                        <div class="d-flex justify-content-between flex-row-reverse">
                            <h6 class="text-muted">مسودات</h6>
                            <h6 class="text-muted"><?php echo e(__('Percentage')); ?></h6>
                        </div>
                        <div class="d-flex  justify-content-between flex-row-reverse">
                            <h4 class="scolor" style="font-weight: 700;">
                                0
                            </h4>
                            <h4 style="font-weight: 700;">
                                0%
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-5">
                <div id="chart2"></div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        var options = {
            chart: {
                type: 'line'
            },
            stroke: {
                curve: 'smooth',
            },
            series: [{
                    name: '<?php echo e(__('Drafts')); ?>',
                    data: [
                        <?php $__currentLoopData = array_reverse($shipment_count['counts_list']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($count); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
                },
                {
                    name: "<?php echo e(__('Delivered')); ?>",
                    data: [
                        <?php $__currentLoopData = array_reverse($shipment_count['counts_list2']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($count); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
                },
                {
                    name: "<?php echo e(__('Processing')); ?>",
                    data: [
                        <?php $__currentLoopData = array_reverse($shipment_count['counts_list1']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($count); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
                },
                {
                    name: "<?php echo e(__('Returned')); ?>",
                    data: [
                        <?php $__currentLoopData = array_reverse($shipment_count['counts_list3']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($count); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
                }
            ],
            xaxis: {
                categories: [
                    <?php $__currentLoopData = $shipment_count['days_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($day); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            }
        }

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        var chart2 = new ApexCharts(document.querySelector("#chart2"), options);

        chart.render();
        chart2.render();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/dashboard.blade.php ENDPATH**/ ?>