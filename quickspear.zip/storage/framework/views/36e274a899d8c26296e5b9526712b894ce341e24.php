<?php $__env->startSection('active1', 'active'); ?>

<?php $__env->startSection('expressContent'); ?>
    <h2 class="mb-4"><?php echo e(__('Local Shipping')); ?></h2>
    <?php if(session()->has('error')): ?>
        <div class="text-center py-4 text-light my-3 bg-danger"><?php echo e(session()->get('error')); ?></div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="text-center py-4 text-light my-3 bg-success"><?php echo e(session()->get('success')); ?></div>
    <?php endif; ?>
    <a class="btn btn-primary mb-3" href="<?php echo e(route('front.express.create')); ?>"><?php echo e(__('Create')); ?></a>
    

    <button type="button" class="btn btn-success mb-3" data-bs-toggle="modal"
        data-bs-target="#exampleModal"><?php echo e(__('Export')); ?></button>

    <button type="button" class="btn btn-secondary mb-3" data-bs-toggle="modal"
        data-bs-target="#filter"><?php echo e(__('Filter')); ?></button>

    <button class="btn btn-primary print_all mb-3" type="button" data-bs-toggle="modal"
        data-bs-target="#exampleModalIDs">Print Selected</button>



    <div class="modal fade" id="exampleModalIDs" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="<?php echo e(route('front.express.printSelectedBulk')); ?>">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('Select All Matching')); ?></label>
                            <input type="text" value="" readonly name="count" class="form-control"
                                id="IDsSelected">
                            <input type="hidden" value="" hidden name="ids" class="form-control"
                                id="IDsSelected2">
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="<?php echo e(route('front.express.export')); ?>">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label"><?php echo e(__('Type')); ?></label>
                            <select name="fileType" class="form-control" id="recipient-name">
                                <option value="pdf">pdf</option>
                                <option value="xlsx">xlsx</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('From')); ?></label>
                            <input type="date" name="from" class="form-control" id="message-text">
                        </div>

                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('To')); ?></label>
                            <input type="date" name="to" class="form-control" id="message-text">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label"><?php echo e(__('Action Status')); ?></label>
                            <select name="acstatus" class="form-control" id="">
                                <option value=""><?php echo e(__('All')); ?></option>
                                <option value="0"><?php echo e(__('New')); ?></option>
                                <option value="1"><?php echo e(__('Processing')); ?></option>
                                <option value="2"><?php echo e(__('Delivered')); ?></option>
                                <option value="3"><?php echo e(__('Returned')); ?></option>
                                <option value="4"><?php echo e(__('Pending Payments')); ?></option>
                                <option value="5"><?php echo e(__('Payment Successful')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="filter" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="">
                    <div class="modal-body">
                        
                        <div class="row">
                            <div class="col-sm-12 col-md-6 mb-3">
                                <label for="message-text" class="col-form-label"><?php echo e(__('From')); ?></label>
                                <input type="date" name="from" class="form-control" id="message-text">
                            </div>

                            <div class="col-sm-12 col-md-6 mb-3">
                                <label for="message-text" class="col-form-label"><?php echo e(__('To')); ?></label>
                                <input type="date" name="to" class="form-control" id="message-text">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label"><?php echo e(__('Action Status')); ?></label>
                            <select name="status" class="form-control" id="recipient-name">
                                <option value="0">New</option>
                                <option value="1">Processing</option>
                                <option value="2">Delivered</option>
                                <option value="3">Returned</option>
                                <option value="4">Pending Payments</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="recipient-process" class="col-form-label"><?php echo e(__('Proccess')); ?></label>
                            <select name="process" class="form-control" id="recipient-process">
                                <option value="<=">Greater Than or equal</option>
                                <option value=">=">Less Than or equal</option>
                                <option value="=">Equal</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="col-form-label"><?php echo e(__('Cash On Delivery')); ?></label>
                            <input type="number" name="cod" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="col-form-label"><?php echo e(__('Phone')); ?></label>
                            <input type="text" name="phone" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="card">
        <ul class="card-header pb-0 nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all"
                    type="button" role="tab" aria-controls="all" aria-selected="true"><?php echo e(__('All')); ?>

                    (<?php echo e($ships->count()); ?>)</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark" id="New-tab" data-bs-toggle="tab" data-bs-target="#New"
                    type="button" role="tab" aria-controls="New" aria-selected="false"><?php echo e(__('New')); ?>

                    (<?php echo e($ships->where('status', 0)->count()); ?>)</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark" id="processing-tab" data-bs-toggle="tab" data-bs-target="#processing"
                    type="button" role="tab" aria-controls="processing"
                    aria-selected="false"><?php echo e(__('Processing')); ?>

                    (<?php echo e($ships->where('status', 1)->count()); ?>)</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark" id="delivered-tab" data-bs-toggle="tab" data-bs-target="#delivered"
                    type="button" role="tab" aria-controls="delivered" aria-selected="false"><?php echo e(__('Delivered')); ?>

                    (<?php echo e($ships->where('status', 2)->count()); ?>)</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark" id="returned-tab" data-bs-toggle="tab" data-bs-target="#returned"
                    type="button" role="tab" aria-controls="returned" aria-selected="false"><?php echo e(__('Returned')); ?>

                    (<?php echo e($ships->where('status', 3)->count()); ?>)</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark" id="pending-payments-tab" data-bs-toggle="tab"
                    data-bs-target="#pending-payments" type="button" role="tab" aria-controls="pending-payments"
                    aria-selected="false"><?php echo e(__('Pending Payments')); ?>

                    (<?php echo e($ships->where('status', 4)->count()); ?>)</button>
            </li>

            <li class="nav-item" role="presentation">
                <button class="nav-link text-dark" id="done-payments-tab" data-bs-toggle="tab"
                    data-bs-target="#done-payments" type="button" role="tab" aria-controls="done-payments"
                    aria-selected="false"><?php echo e(__('Payment Successful')); ?>

                    (<?php echo e($ships->where('status', 5)->count()); ?>)</button>
            </li>
        </ul>
        
        <div class="card-body tab-content" id="myTabContent">
            <div class="tab-pane fade show rounded-3 active" id="all" role="tabpanel" aria-labelledby="all-tab">
                <?php echo e($dataTable->table()); ?>

                
            </div>
            <div class="tab-pane fade show rounded-3" id="New" role="tabpanel" aria-labelledby="New-tab">
                
                <table class="table border text-center datatable" id="datatable">
                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th><?php echo e(__('Created.')); ?></th>
                            <th>AWB</th>
                            <th><?php echo e(__('Consignee')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Cash On Delivery')); ?></th>
                            <th><?php echo e(__('Provider')); ?></th>
                            <th><?php echo e(__('Action Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $ships->where('status', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($ship->id); ?>"></td>
                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                <td><?php echo e($ship->shipmentID); ?></td>
                                <td><?php echo e($ship->consignee_name); ?></td>
                                <td><?php echo e($ship->consignee_phone); ?></td>
                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                <td>Aramex</td>
                                <td><?php echo e(__($ship->get_status())); ?></td>
                                <td>
                                    <?php
                                    $shipmentImp = App\Models\ShipmentImport::where('awb', $ship->shipmentID)->first();
                                    if ($shipmentImp) {
                                        $transaction = App\Models\Transaction::find($shipmentImp->transaction_id);
                                    }
                                    
                                ?>
                                <?php if($shipmentImp): ?> <?php if($transaction): ?> <?php if($transaction->image != 'N/A'): ?>  <a href="<?php echo e(url($transaction->image)); ?>" style="background-color: yellow; border-color: yellow;" target="_blanck" class="btn btn-info"><span class="text text-warning">$</span></a> <?php endif; ?> <?php endif; ?> <?php endif; ?>
                                    <a class="btn btn-success" href="<?php echo e(route('front.express.show', $ship->id)); ?>"><i
                                            class="fa fa-eye"></i> <?php echo e(__('Showing')); ?></a>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"><?php echo e(__('Editing Orders')); ?></button>

                                    <div class="modal fade" id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label">
                                                        <?php echo e(__('Editing Orders')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST"
                                                    action="<?php echo e(route('front.express.shipment_update')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <input type="hidden" name="shipment_id"
                                                                value="<?php echo e($ship->id); ?>" class="form-control"
                                                                id="recipient-name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="message-text"
                                                                class="col-form-label"><?php echo e(__('Description')); ?></label>
                                                            <textarea class="form-control" name="desc" id="message-text"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade show rounded-3" id="processing" role="tabpanel" aria-labelledby="processing-tab">
                <table class="table border text-center datatable" id="datatable">
                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th><?php echo e(__('Created.')); ?></th>
                            <th>AWB</th>
                            <th><?php echo e(__('Consignee')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Cash On Delivery')); ?></th>
                            <th><?php echo e(__('Provider')); ?></th>
                            <th><?php echo e(__('Action Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $ships->where('status', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($ship->id); ?>"></td>
                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                <td><?php echo e($ship->shipmentID); ?></td>
                                <td><?php echo e($ship->consignee_name); ?></td>
                                <td><?php echo e($ship->consignee_phone); ?></td>
                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                <td>Aramex</td>
                                <td><?php echo e(__($ship->get_status())); ?></td>
                                <td>
                                    <a class="btn btn-success" href="<?php echo e(route('front.express.show', $ship->id)); ?>"><i
                                            class="fa fa-eye"></i> <?php echo e(__('Showing')); ?></a>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"><?php echo e(__('Editing Orders')); ?></button>

                                    <div class="modal fade" id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label">
                                                        <?php echo e(__('Editing Orders')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST"
                                                    action="<?php echo e(route('front.express.shipment_update')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <input type="hidden" name="shipment_id"
                                                                value="<?php echo e($ship->id); ?>" class="form-control"
                                                                id="recipient-name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="message-text"
                                                                class="col-form-label"><?php echo e(__('Description')); ?></label>
                                                            <textarea class="form-control" name="desc" id="message-text"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade show rounded-3" id="delivered" role="tabpanel" aria-labelledby="delivered-tab">
                <table class="table border text-center datatable" id="datatable">
                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th><?php echo e(__('Created.')); ?></th>
                            <th>AWB</th>
                            <th><?php echo e(__('Consignee')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Cash On Delivery')); ?></th>
                            <th><?php echo e(__('Provider')); ?></th>
                            <th><?php echo e(__('Action Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $ships->where('status', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($ship->id); ?>"></td>
                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                <td><?php echo e($ship->shipmentID); ?></td>
                                <td><?php echo e($ship->consignee_name); ?></td>
                                <td><?php echo e($ship->consignee_phone); ?></td>
                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                <td>Aramex</td>
                                <td><?php echo e(__($ship->get_status())); ?></td>
                                <td>
                                    <?php
                                    $shipmentImp = App\Models\ShipmentImport::where('awb', $ship->shipmentID)->first();
                                    if ($shipmentImp) {
                                        $transaction = App\Models\Transaction::find($shipmentImp->transaction_id);
                                    }
                                    
                                ?>
                                <?php if($shipmentImp): ?> <?php if($transaction): ?> <?php if($transaction->image != 'N/A'): ?>  <a href="<?php echo e(url($transaction->image)); ?>" style="background-color: yellow; border-color: yellow;" target="_blanck" class="btn btn-info"><span class="text text-warning">$</span></a> <?php endif; ?> <?php endif; ?> <?php endif; ?>
                                    <a class="btn btn-success" href="<?php echo e(route('front.express.show', $ship->id)); ?>"><i
                                            class="fa fa-eye"></i> <?php echo e(__('Showing')); ?></a>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"><?php echo e(__('Editing Orders')); ?></button>

                                    <div class="modal fade" id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label">
                                                        <?php echo e(__('Editing Orders')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST"
                                                    action="<?php echo e(route('front.express.shipment_update')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <input type="hidden" name="shipment_id"
                                                                value="<?php echo e($ship->id); ?>" class="form-control"
                                                                id="recipient-name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="message-text"
                                                                class="col-form-label"><?php echo e(__('Description')); ?></label>
                                                            <textarea class="form-control" name="desc" id="message-text"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade show rounded-3" id="returned" role="tabpanel" aria-labelledby="returned-tab">
                <table class="table border text-center datatable" id="datatable">
                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th><?php echo e(__('Created.')); ?></th>
                            <th>AWB</th>
                            <th><?php echo e(__('Consignee')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Cash On Delivery')); ?></th>
                            <th><?php echo e(__('Provider')); ?></th>
                            <th><?php echo e(__('Action Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $ships->where('status', 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($ship->id); ?>"></td>
                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                <td><?php echo e($ship->shipmentID); ?></td>
                                <td><?php echo e($ship->consignee_name); ?></td>
                                <td><?php echo e($ship->consignee_phone); ?></td>
                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                <td>Aramex</td>
                                <td><?php echo e(__($ship->get_status())); ?></td>
                                <td>
                                    <?php
                                    $shipmentImp = App\Models\ShipmentImport::where('awb', $ship->shipmentID)->first();
                                    if ($shipmentImp) {
                                        $transaction = App\Models\Transaction::find($shipmentImp->transaction_id);
                                    }
                                    
                                ?>
                                <?php if($shipmentImp): ?> <?php if($transaction): ?> <?php if($transaction->image != 'N/A'): ?>  <a href="<?php echo e(url($transaction->image)); ?>" style="background-color: yellow; border-color: yellow;" target="_blanck" class="btn btn-info"><span class="text text-warning">$</span></a> <?php endif; ?> <?php endif; ?> <?php endif; ?>
                                    <a class="btn btn-success" href="<?php echo e(route('front.express.show', $ship->id)); ?>"><i
                                            class="fa fa-eye"></i> <?php echo e(__('Showing')); ?></a>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"><?php echo e(__('Editing Orders')); ?></button>

                                    <div class="modal fade" id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label">
                                                        <?php echo e(__('Editing Orders')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST"
                                                    action="<?php echo e(route('front.express.shipment_update')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <input type="hidden" name="shipment_id"
                                                                value="<?php echo e($ship->id); ?>" class="form-control"
                                                                id="recipient-name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="message-text"
                                                                class="col-form-label"><?php echo e(__('Description')); ?></label>
                                                            <textarea class="form-control" name="desc" id="message-text"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade show rounded-3" id="pending-payments" role="tabpanel"
                aria-labelledby="pending-payments-tab">
                <table class="table border text-center datatable" id="datatable">
                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th><?php echo e(__('Created.')); ?></th>
                            <th>AWB</th>
                            <th><?php echo e(__('Consignee')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Cash On Delivery')); ?></th>
                            <th><?php echo e(__('Provider')); ?></th>
                            <th><?php echo e(__('Action Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $ships->where('status', 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($ship->id); ?>"></td>
                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                <td><?php echo e($ship->shipmentID); ?></td>
                                <td><?php echo e($ship->consignee_name); ?></td>
                                <td><?php echo e($ship->consignee_phone); ?></td>
                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                <td>Aramex</td>
                                <td><?php echo e(__($ship->get_status())); ?></td>
                                <td>
                                    <?php
                                    $shipmentImp = App\Models\ShipmentImport::where('awb', $ship->shipmentID)->first();
                                    if ($shipmentImp) {
                                        $transaction = App\Models\Transaction::find($shipmentImp->transaction_id);
                                    }
                                    
                                ?>
                                <?php if($shipmentImp): ?> <?php if($transaction): ?> <?php if($transaction->image != 'N/A'): ?>  <a href="<?php echo e(url($transaction->image)); ?>" style="background-color: yellow; border-color: yellow;" target="_blanck" class="btn btn-info"><span class="text text-warning">$</span></a> <?php endif; ?> <?php endif; ?> <?php endif; ?>
                                    <a class="btn btn-success" href="<?php echo e(route('front.express.show', $ship->id)); ?>"><i
                                            class="fa fa-eye"></i> <?php echo e(__('Showing')); ?></a>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"><?php echo e(__('Editing Orders')); ?></button>

                                    <div class="modal fade" id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label">
                                                        <?php echo e(__('Editing Orders')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST"
                                                    action="<?php echo e(route('front.express.shipment_update')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <input type="hidden" name="shipment_id"
                                                                value="<?php echo e($ship->id); ?>" class="form-control"
                                                                id="recipient-name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="message-text"
                                                                class="col-form-label"><?php echo e(__('Description')); ?></label>
                                                            <textarea class="form-control" name="desc" id="message-text"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="tab-pane fade show rounded-3" id="done-payments" role="tabpanel"
                aria-labelledby="done-payments-tab">
                <table class="table border text-center datatable" id="datatable">
                    <thead>
                        <tr>
                            <th width="50px"><input type="checkbox" id="master"></th>
                            <th><?php echo e(__('Created.')); ?></th>
                            <th>AWB</th>
                            <th><?php echo e(__('Consignee')); ?></th>
                            <th><?php echo e(__('Phone')); ?></th>
                            <th><?php echo e(__('Cash On Delivery')); ?></th>
                            <th><?php echo e(__('Provider')); ?></th>
                            <th><?php echo e(__('Action Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $ships->where('status', 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($ship->id); ?>"></td>
                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                <td><?php echo e($ship->shipmentID); ?></td>
                                <td><?php echo e($ship->consignee_name); ?></td>
                                <td><?php echo e($ship->consignee_phone); ?></td>
                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                <td>Aramex</td>
                                <td><?php echo e(__($ship->get_status())); ?></td>
                                <td>
                                    <?php
                                    $shipmentImp = App\Models\ShipmentImport::where('awb', $ship->shipmentID)->first();
                                    if ($shipmentImp) {
                                        $transaction = App\Models\Transaction::find($shipmentImp->transaction_id);
                                    }
                                    
                                ?>
                                <?php if($shipmentImp): ?> <?php if($transaction): ?> <?php if($transaction->image != 'N/A'): ?>  <a href="<?php echo e(url($transaction->image)); ?>" style="background-color: yellow; border-color: yellow;" target="_blanck" class="btn btn-info"><span class="text text-warning">$</span></a> <?php endif; ?> <?php endif; ?> <?php endif; ?>
                                    <a class="btn btn-success" href="<?php echo e(route('front.express.show', $ship->id)); ?>"><i
                                            class="fa fa-eye"></i> <?php echo e(__('Showing')); ?></a>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"><?php echo e(__('Editing Orders')); ?></button>

                                    <div class="modal fade" id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"
                                                        id="editOrder_<?php echo e($ship->status . '_' . $ship->id); ?>Label">
                                                        <?php echo e(__('Editing Orders')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST"
                                                    action="<?php echo e(route('front.express.shipment_update')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <input type="hidden" name="shipment_id"
                                                                value="<?php echo e($ship->id); ?>" class="form-control"
                                                                id="recipient-name">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="message-text"
                                                                class="col-form-label"><?php echo e(__('Description')); ?></label>
                                                            <textarea class="form-control" name="desc" id="message-text"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Apply')); ?></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts()); ?>      
   <?php $__env->stopPush(); ?>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.express.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/express/shipping.blade.php ENDPATH**/ ?>