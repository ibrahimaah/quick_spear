<?php $__env->startSection('active7', 'active'); ?>
<?php $__env->startSection('accountContent'); ?>
<div class="row mt-5">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5><?php echo e(__('Shipping Price')); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table border table-sm scroll-horizontal datatable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('City') . ' (' . __('From') . ')'); ?></th>
                                <th><?php echo e(__('City') . ' (' . __('To') . ')'); ?></th>
                                <th><?php echo e(__('Cost')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rates->where('user_id', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                 <td><?php echo e($rate->city_r_from->name); ?></td>
                                <td><?php echo e($rate->city_r_to->name); ?></td>
                                <td><?php echo e($rate->rate); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-5">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5><?php echo e(__('Shipping Price For You')); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table border table-sm scroll-horizontal datatable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('City') . ' (' . __('From') . ')'); ?></th>
                                <th><?php echo e(__('City') . ' (' . __('To') . ')'); ?></th>
                                <th><?php echo e(__('Cost')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rates->where('user_id', auth()->user()->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                 <td><?php echo e($rate->city_r_from->name); ?></td>
                                <td><?php echo e($rate->city_r_to->name); ?></td>
                                <td><?php echo e($rate->rate); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.account.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/account/rates.blade.php ENDPATH**/ ?>