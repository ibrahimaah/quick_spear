<?php $__env->startSection('title', 'المستخدمين'); ?>
<?php $__env->startSection('content'); ?>
    <ul class="nav nav-pills mb-3 p-4" id="pills-tab" role="tablist">
        <li class="nav-item mx-3" role="presentation">
            <a href="#" class="nav-link active" id="pills-account-info-tab" data-bs-toggle="pill"
                data-bs-target="#pills-account-info" role="tab" aria-controls="pills-account-info"
                aria-selected="true">البيانات الاساسية</a>
        </li>
        <li class="nav-item mx-3" role="presentation">
            <a href="#" class="nav-link" id="pills-shipping-tab" data-bs-toggle="pill"
                data-bs-target="#pills-shipping" role="tab" aria-controls="pills-shipping" aria-selected="false">الشحن
                (<?php echo e($user->shipments->count()); ?>)</a>
        </li>
        <li class="nav-item mx-3" role="presentation">
            <a href="#" class="nav-link" id="pills-documents-tab" data-bs-toggle="pill"
                data-bs-target="#pills-documents" role="tab" aria-controls="pills-documents"
                aria-selected="false">الوثائق (<?php echo e($documents->count()); ?>)</a>
        </li>

        <li class="nav-item mx-3" role="presentation">
            <a href="#" class="nav-link" id="pills-payments-tab" data-bs-toggle="pill"
                data-bs-target="#pills-payments" role="tab" aria-controls="pills-payments" aria-selected="false">وسائل
                الدفع (<?php echo e($payments->count()); ?>)</a>
        </li>
    </ul>
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-account-info" role="tabpanel"
            aria-labelledby="pills-account-info-tab">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="card-header">
                                <h4>معلومات الحساب</h4>
                            </div>
                            <div class="card-body">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 my-2 col-md-4">
                                            <label>رقم الحساب</label>
                                            <p class="card-text">
                                                <?php echo e($user->ACCOUNT_NUMBER()); ?>

                                            </p>
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>الدولة</label>
                                            <p class="card-text">
                                                الاردن
                                            </p>
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>العملة</label>
                                            <p class="card-text">
                                                JOD
                                            </p>
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>نوع الحساب</label>
                                            <p class="card-text">
                                                <?php echo e($user->type ?? 'شخصي'); ?>

                                            </p>
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>رقم الهاتف</label>
                                            <p class="card-text">
                                                <?php echo e($user->phone); ?>

                                            </p>
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>البريد الإلكتروني</label>
                                            <p class="card-text">
                                                <?php echo e($user->email); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-12 my-2 col-md-4">
                                            <label>الاسم</label><span class="text-danger">*</span>
                                            <input class="form-control mt-2 ml-2" type="text" value="<?php echo e($user->name); ?>"
                                                name="name" />
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>رقم الهاتف</label><span class="text-danger">*</span>
                                            <input class="form-control mt-2 ml-2" type="text" value="<?php echo e($user->phone); ?>"
                                                name="phone" />
                                        </div>
                                        <div class="col-12 my-2 col-md-4">
                                            <label>البريد الالكتروني</label><span class="text-danger">*</span>
                                            <input class="form-control mt-2 ml-2" type="text"
                                                value="<?php echo e($user->email); ?>" name="email" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-header">
                                <button class="btn btn-primary" type="submit">تحديث</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="pills-shipping" role="tabpanel" aria-labelledby="pills-shipping-tab">
            <div class="row mt-5">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>الشحنات</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border table-sm scroll-horizontal basic-1">
                                    <thead>
                                        <tr>
                                            <th>التاريخ</th>
                                            <th>AWB</th>
                                            <th>المرسل إليه</th>
                                            <th>رقم الهاتف</th>
                                            <th>الدفع عند الاستلام</th>
                                            <th>الناقل</th>
                                            <th>الحالة</th>
                                            <th>إجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $user->shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th><?php echo e($ship->created_at->format('Y - m - d')); ?></th>
                                                <td><?php echo e($ship->shipmentID); ?></td>
                                                <td><?php echo e($ship->consignee_name); ?></td>
                                                <td><?php echo e($ship->consignee_phone); ?></td>
                                                <td><?php echo e($ship->cash_on_delivery_amount ?? '0'); ?></td>
                                                <td>Aramex</td>
                                                <td>
                                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('shipment-all', ['shipment' => $ship])->html();
} elseif ($_instance->childHasBeenRendered($ship->id)) {
    $componentId = $_instance->getRenderedChildComponentId($ship->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($ship->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($ship->id);
} else {
    $response = \Livewire\Livewire::mount('shipment-all', ['shipment' => $ship]);
    $html = $response->html();
    $_instance->logRenderedChild($ship->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                </td>
                                                <td>
                                                    <a class=""
                                                        href="<?php echo e(route('admin.shipments.show', $ship->id)); ?>"><i
                                                            class="fa fa-eye"></i> عرض</a>
                                                    <a class=""
                                                        href="<?php echo e(route('admin.shipments.edit', $ship->id)); ?>"><i
                                                            class="fa fa-edit"></i> تعديل</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>اسعار الشحن</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border table-sm scroll-horizontal basic-1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>المدينة (من)</th>
                                            <th>المدينة (إلى)</th>
                                            <th>التكلفة</th>
                                            <th>العمليات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rates->where('user_id', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($rate->city_r_from->name); ?></td>
                                                <td><?php echo e($rate->city_r_to->name); ?></td>
                                                <td><?php echo e($rate->rate); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#edit-rate-<?php echo e($rate->id); ?>">
                                                        تعديل لهذا المستخدم
                                                    </button>

                                                    <div class="modal fade" id="edit-rate-<?php echo e($rate->id); ?>"
                                                        tabindex="-1" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <form method="post"
                                                                    action="<?php echo e(route('admin.cities.add_rate')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" value="<?php echo e($rate->city_from); ?>"
                                                                        name="from">
                                                                    <input type="hidden" value="<?php echo e($rate->city_to); ?>"
                                                                        name="to">
                                                                    <input type="hidden" value="<?php echo e($user->id); ?>"
                                                                        name="user_id">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            تعديل</h5>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="mb-3 row">
                                                                            <label class="col-sm-3 col-form-label"
                                                                                for="exampleFormControlInput1">تكلفة
                                                                                الشحن</label>
                                                                            <div class="col-sm-9">
                                                                                <input
                                                                                    class="form-control <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    name="rate"
                                                                                    id="exampleFormControlInput1"
                                                                                    type="text"
                                                                                    value="<?php echo e($rate->rate); ?>">
                                                                                <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <div class="invalid-feedback">
                                                                                        <?php echo e($message); ?></div>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">إغلاق</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">اضافة</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <a class="btn btn-danger" href="#"
                                                        onclick="event.preventDefault();document.getElementById('delete-rate-<?php echo e($rate->id); ?>').submit();"><i
                                                            class="fa fa-trash"></i></a>
                                                    <form action="<?php echo e(route('admin.cities.rate_destroy', $rate->id)); ?>"
                                                        method="post" class="d-none"
                                                        id="delete-rate-<?php echo e($rate->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>اسعار الشحن لهذا المستخدم</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border table-sm scroll-horizontal basic-1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>المدينة (من)</th>
                                            <th>المدينة (إلى)</th>
                                            <th>التكلفة</th>
                                            <th>العمليات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rates->where('user_id', $user->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($rate->city_r_from->name); ?></td>
                                                <td><?php echo e($rate->city_r_to->name); ?></td>
                                                <td><?php echo e($rate->rate); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#edit-rate2-<?php echo e($rate->id); ?>">
                                                        تعديل
                                                    </button>

                                                    <div class="modal fade" id="edit-rate2-<?php echo e($rate->id); ?>"
                                                        tabindex="-1" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <form method="post"
                                                                    action="<?php echo e(route('admin.cities.add_rate')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" value="<?php echo e($rate->city_from); ?>"
                                                                        name="from">
                                                                    <input type="hidden" value="<?php echo e($rate->city_to); ?>"
                                                                        name="to">
                                                                    <input type="hidden" value="<?php echo e($user->id); ?>"
                                                                        name="user_id">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            تعديل</h5>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="mb-3 row">
                                                                            <label class="col-sm-3 col-form-label"
                                                                                for="exampleFormControlInput1">تكلفة
                                                                                الشحن</label>
                                                                            <div class="col-sm-9">
                                                                                <input
                                                                                    class="form-control <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    name="rate"
                                                                                    id="exampleFormControlInput1"
                                                                                    type="text"
                                                                                    value="<?php echo e($rate->rate); ?>">
                                                                                <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <div class="invalid-feedback">
                                                                                        <?php echo e($message); ?></div>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">إغلاق</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">اضافة</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <a class="btn btn-danger" href="#"
                                                        onclick="event.preventDefault();document.getElementById('delete-rate-<?php echo e($rate->id); ?>').submit();"><i
                                                            class="fa fa-trash"></i></a>
                                                    <form action="<?php echo e(route('admin.cities.rate_destroy', $rate->id)); ?>"
                                                        method="post" class="d-none"
                                                        id="delete-rate-<?php echo e($rate->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="pills-documents" role="tabpanel" aria-labelledby="pills-documents-tab">
            <div id="documents" class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>الوثائق</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>تم التقديم</th>
                                            <th>النوع</th>
                                            <th>الحالة</th>
                                            <th>الاجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($document->created_at); ?></td>
                                                <td><?php echo e($document->type); ?></td>
                                                <td>
                                                    <?php if($document->statusVerify == 1): ?>
                                                        <span class="badge bg-success">تم التحقق</span>
                                                    <?php elseif($document->statusVerify == 2): ?>
                                                        <span class="badge bg-success">تم الرفض</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-success">قيد المراجعه</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#delete-<?php echo e($document->id); ?>">حذف</button>
                                                    <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                                        data-bs-target="#update-<?php echo e($document->id); ?>">تحديث الحالة</button>

                                                    <div class="modal fade" id="delete-<?php echo e($document->id); ?>"
                                                        tabindex="-1" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close"
                                                                        data-bs-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <form
                                                                    action="<?php echo e(route('admin.users.documents_delete', $document->id)); ?>"
                                                                    method="POST">
                                                                    <div class="modal-body">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        هل انت متأكد من المتابعه ؟
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">اغلاق</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">متابعة</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="modal fade" id="update-<?php echo e($document->id); ?>"
                                                        tabindex="-1" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close"
                                                                        data-bs-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <form
                                                                    action="<?php echo e(route('admin.users.documents_update', $document->id)); ?>"
                                                                    method="POST">
                                                                    <div class="modal-body">
                                                                        <?php echo csrf_field(); ?>
                                                                        <img src="<?php echo e(asset($document->document)); ?>"
                                                                            width="100%" alt="">
                                                                        <div class="form-group">
                                                                            <label for="status"
                                                                                class="col-form-label">الحالة</label>
                                                                            <select name="status" class="form-control"
                                                                                id="status">
                                                                                <option value="0"
                                                                                    <?php echo e($document->statusVerify == 0 ? 'selected' : ''); ?>>
                                                                                    قيد المراجعة</option>
                                                                                <option value="1"
                                                                                    <?php echo e($document->statusVerify == 1 ? 'selected' : ''); ?>>
                                                                                    تم التحقق</option>
                                                                                <option value="2"
                                                                                    <?php echo e($document->statusVerify == 2 ? 'selected' : ''); ?>>
                                                                                    رفض</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">اغلاق</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">متابعة</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="pills-payments" role="tabpanel" aria-labelledby="pills-payments-tab">
            <div id="documents" class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>وسائل الدفع</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>اسم الحساب</th>
                                            <th>المزود</th>
                                            <th>IBAN/المحفظة</th>
                                            <th>الاجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($payment->name); ?></td>
                                                <td><?php echo e($payment->provider); ?></td>
                                                <td><?php echo e($payment->iban_or_number); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#delete-<?php echo e($payment->id); ?>">حذف</button>

                                                    <div class="modal fade" id="delete-<?php echo e($payment->id); ?>"
                                                        tabindex="-1" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close"
                                                                        data-bs-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <form
                                                                    action="<?php echo e(route('admin.users.payments_delete', $payment->id)); ?>"
                                                                    method="POST">
                                                                    <div class="modal-body">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        هل انت متأكد من المتابعه ؟
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">اغلاق</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">متابعة</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/admin/users/show.blade.php ENDPATH**/ ?>