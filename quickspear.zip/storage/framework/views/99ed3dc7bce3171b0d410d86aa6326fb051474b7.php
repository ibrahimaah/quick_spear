<ul class="notification-dropdown onhover-show-div" wire:poll>
    <li>
        <i data-feather="bell"></i>
        <h6 class="f-18 mb-0">التنبيهات</h6>
    </li>

    <?php $__currentLoopData = auth()->user()->notifications->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notiy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($notiy->type == "App\Notifications\OrderNotification"): ?>
    <li class="mb-3 py-3">
        <a onclick="<?php echo e(auth()->user()->notifications->where('id', $notiy->id)->markAsRead()); ?>;" href="<?php echo e(route('admin.shipments.show', $notiy->data['shipment_id'] ?? '')); ?>?notification_id=<?php echo e($notiy->id); ?>">
            <p>
                <i class="fa fa-circle-o me-3 font-success"> </i>
                <?php echo e($notiy->data['body'] ?? ''); ?>

                <span class="pull-right"><?php echo e($notiy->created_at); ?></span>
            </p>
        </a>
    </li>
    <?php elseif($notiy->type == "App\Notifications\NewUserNotification"): ?>
    <li class="mb-3 py-3">
        <a onclick="<?php echo e(auth()->user()->notifications->where('id', $notiy->id)->markAsRead()); ?>;" href="<?php echo e(route('admin.users.show', $notiy->data['user_id'] ?? '')); ?>?notification_id=<?php echo e($notiy->id); ?>">
            <p>
                <i class="fa fa-circle-o me-3 font-success"> </i>
                <?php echo e($notiy->data['body'] ?? ''); ?>

                <span class="pull-right"><?php echo e($notiy->created_at); ?></span>
            </p>
        </a>
    </li>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</ul>
<?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/livewire/notifications.blade.php ENDPATH**/ ?>