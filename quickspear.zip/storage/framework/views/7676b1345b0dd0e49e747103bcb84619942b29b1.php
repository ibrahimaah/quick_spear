<?php $__env->startSection('expressContent'); ?>
<h2 class="mb-4"><?php echo e(__('Create')); ?> <?php echo e(__('Local Shipping')); ?></h2>
<a class="btn btn-primary mb-3" href="<?php echo e(route('front.get_shipments_import')); ?>"><?php echo e(__('Excel Import')); ?></a>
<a class="btn btn-success mb-3" href="<?php echo e(asset('assets/file.xlsx')); ?>"><?php echo e(__('Excel Import Format')); ?></a>
<div class="card">
    <?php if(session()->has('error')): ?>
        <div class="alert text-center py-4 text-light my-3 alert-danger"><?php echo e(session()->get('error')); ?></div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert text-center py-4 text-light my-3 alert-success"><?php echo e(session()->get('success')); ?></div>
    <?php endif; ?>
    <div class="card-header">
        
    </div>
    <div class="card-body">
        <div class="container">
            <form method="post" action="<?php echo e(route('front.express.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="d-lg-flex flex-row col-sm-12 mb-3 justify-content-center">
                        <div class="col-xl-5 col-sm-12 col-lg-7 px-0 mb-2">
                            <label><?php echo e(__('Shipper')); ?></label><span class="text-danger">*</span>
                            <select class="form-control mt-2 ml-2 " name="shipper">
                                <?php $__currentLoopData = auth()->user()->addresses->where('type', 0)->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($address->id); ?>">
                                    <?php echo e($address->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <a href="<?php echo e(route('front.user.address')); ?>" style="height: 37px;margin-top: 3.3% !important;" class="btn btn-primary ml-xl-3 mr-xl-3 mx-3"><?php echo e(__('New Address')); ?></a>
                        <div class="col-xl-5 col-sm-12 col-lg-3
                              px-0 px-sm-0
                              mb-2
                              ml-xl-3
                              mt-2 mt-lg-0">
                            <label><?php echo e(__('Provider')); ?></label><span class="text-danger">*</span>
                            <select class="form-control mt-2" name="provider">
                                <option value="aramex" selected>Aramex</option>
                            </select>
                        </div>
                    </div>
                    <hr />
                </div>
                <div class="row">
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Consignee Name')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="consignee_name" />
                        <?php $__errorArgs = ['consignee_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Phone')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="consignee_phone" />
                        <?php $__errorArgs = ['consignee_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Phone')); ?> 2</label>
                        <input class="form-control mt-2 ml-2" type="text" name="consignee_cell_phone" />
                        <?php $__errorArgs = ['consignee_cell_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('City')); ?></label><span class="text-danger">*</span>
                        <select class="form-control mt-2 ml-2" type="text" name="consignee_city">
                            <?php $__currentLoopData = App\Models\City::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['consignee_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Region')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="consignee_line2" />
                        <?php $__errorArgs = ['consignee_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Description')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="consignee_line1" />
                        <?php $__errorArgs = ['consignee_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Weight')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="weight" />
                        <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Contents')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="description" />
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Comments')); ?></label>
                        <input class="form-control mt-2 ml-2" type="text" name="comments" />
                        <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Reference')); ?></label>
                        <input class="form-control mt-2 ml-2" type="text" value="<?php echo e(auth()->user()->ACCOUNT_NUMBER()); ?>" name="reference" />
                        <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Number OF Pieces')); ?></label><span class="text-danger">*</span>
                        <input class="form-control mt-2 ml-2" type="text" name="number_of_pieces" />
                        <?php $__errorArgs = ['number_of_pieces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 my-2 col-md-4">
                        <label><?php echo e(__('Cash On Delivery')); ?> (JOD)</label>
                        <input class="form-control mt-2 ml-2" type="text" name="cash_on_delivery_amount" />
                        <?php $__errorArgs = ['cash_on_delivery_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                </div>
                <button class="btn btn-primary btn-lg my-3" type="submit"><?php echo e(__('Apply')); ?></button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.express.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/express/create.blade.php ENDPATH**/ ?>