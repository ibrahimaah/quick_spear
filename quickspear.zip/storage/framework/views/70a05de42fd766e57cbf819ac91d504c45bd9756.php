<?php $__env->startSection('expressContent'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php if(session()->has('error')): ?>
                <div class="alert text-center py-4 text-light my-3 alert-danger"><?php echo e(session()->get('error')); ?></div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
                <div class="alert text-center py-4 text-light my-3 alert-success"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h5><?php echo e(__('Excel Import')); ?></h5>
                </div>
                <form class="form theme-form" method="POST" action="<?php echo e(route('front.shipments_import')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="mb-3 row">
                            <label class="col-sm-3 col-form-label"
                                for="exampleFormControlInput1"><?php echo e(__('Choose File')); ?></label>
                            <div class="col-sm-9">
                                <input class="form-control <?php $__errorArgs = ['importFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="importFile"
                                    type="file">
                                <?php $__errorArgs = ['importFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-end">
                        <button class="btn btn-primary" type="submit"><?php echo e(__('Apply')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row my-5 py-2">
        <div class="col-sm-12">
            
                <form class="form theme-form" method="POST" action="<?php echo e(route('front.express.store')); ?>">
                <?php echo csrf_field(); ?>
                <div id="repeater">
                    <?php if(isset($rows)): ?>
                        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <div class="items my-2" data-group="shipments">
                                <!-- Repeater Content -->
                                <div class="item-content">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>#<?php echo e($loop->iteration); ?></h5>
                                        </div>
                                        <div class="container">
                                            <div class="row">
                                                <div class="d-lg-flex flex-row col-sm-12 mb-3 justify-content-center">
                                                    <div class="col-xl-5 col-sm-12 col-lg-7 px-0 mb-2">
                                                        <label><?php echo e(__('Shipper')); ?></label><span class="text-danger">*</span>
                                                        <select class="form-control mt-2 ml-2 " data-name="shipper">

                                                            <?php $__currentLoopData = auth()->user()->addresses->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($row['address2'] && $row['address2']->id == $address->id): ?>
                                                                    <option
                                                                        <?php echo e($row['address2']->id ?? 0 == $address->id ? 'selected' : ''); ?>

                                                                        value="<?php echo e($address->id); ?>">
                                                                        <?php echo e($address->name); ?>

                                                                    </option>
                                                                    <?php else: ?>
                                                                    <option
                                                                        <?php echo e($row['address2']->id ?? 0 == $address->id ? 'selected' : ''); ?>

                                                                        value="<?php echo e($address->id); ?>">
                                                                        <?php echo e($address->name); ?>

                                                                    </option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <a href="<?php echo e(route('front.user.address')); ?>"
                                                        style="height: 37px;margin-top: 3.3% !important;"
                                                        class="btn btn-primary ml-xl-3 mr-xl-3 mx-3"><?php echo e(__('New Address')); ?></a>
                                                    <div
                                                        class="col-xl-5 col-sm-12 col-lg-3
                                                px-0 px-sm-0
                                                mb-2
                                                ml-xl-3
                                                mt-2 mt-lg-0">
                                                        <label><?php echo e(__('Provider')); ?></label><span class="text-danger">*</span>
                                                        <select class="form-control mt-2" data-name="provider">
                                                            <option value="aramex" selected>Aramex</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <hr />
                                            </div>
                                            <div class="row">
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Consignee Name')); ?></label><span class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" value="<?php echo e($row['consignee_name']); ?>"
                                                        type="text" data-name="consignee_name" />
                                                    <?php $__errorArgs = ['consignee_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Phone')); ?></label><span class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="consignee_phone" value="<?php echo e($row['phone_number']); ?>" />
                                                    <?php $__errorArgs = ['consignee_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Phone')); ?> 2</label>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="consignee_cell_phone"
                                                        value="<?php echo e($row['secondary_phone_number']); ?>" />
                                                    <?php $__errorArgs = ['consignee_cell_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('City')); ?></label><span class="text-danger">*</span>
                                                    <select class="form-control mt-2 ml-2" type="text"
                                                        data-name="consignee_city">
                                                        <?php $__currentLoopData = App\Models\City::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php echo e($row['city1']->id == $city->id ? 'selected' : ''); ?>

                                                                value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['consignee_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Region')); ?></label><span class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="consignee_line2" value="<?php echo e($row['area']); ?>" />
                                                    <?php $__errorArgs = ['consignee_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Description')); ?></label><span class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="consignee_line1" value="<?php echo e($row['detailed_address']); ?>" />
                                                    <?php $__errorArgs = ['consignee_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Weight')); ?></label><span class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" type="text" data-name="weight"
                                                        value="<?php echo e($row['weight'] ?? ''); ?>" />
                                                    <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Contents')); ?></label><span class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="description" value="<?php echo e($row['shipment_content']); ?>" />
                                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Comments')); ?></label>
                                                    <input class="form-control mt-2 ml-2" type="text" data-name="comments"
                                                        value="<?php echo e($row['notes']); ?>" />
                                                    <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Reference')); ?></label>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        value="<?php echo e(auth()->user()->ACCOUNT_NUMBER() ??auth('team')->user()->team->ACCOUNT_NUMBER()); ?>"
                                                        data-name="reference" />
                                                    <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Number OF Pieces')); ?></label><span
                                                        class="text-danger">*</span>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="number_of_pieces" value="<?php echo e($row['pieces']); ?>" />
                                                    <?php $__errorArgs = ['number_of_pieces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 my-2 col-md-4">
                                                    <label><?php echo e(__('Cash On Delivery')); ?> (JOD)</label>
                                                    <input class="form-control mt-2 ml-2" type="text"
                                                        data-name="cash_on_delivery_amount" value="<?php echo e($row['cod']); ?>" />
                                                    <?php $__errorArgs = ['cash_on_delivery_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Repeater Remove Btn -->
                                <div class="repeater-remove-btn">
                                    <button class="btn btn-danger remove-btn">
                                        <?php echo e(__('Delete')); ?>

                                    </button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-success btn-block mx-auto my-5"><?php echo e(__('Apply')); ?></button>
                </form>
                <!-- Repeater End -->
                
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.user.express.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558169062/domains/metafortech.com/public_html/quickspear/resources/views/pages/user/express/import.blade.php ENDPATH**/ ?>