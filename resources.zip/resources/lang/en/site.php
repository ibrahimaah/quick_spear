<?php

return [
    'home'                      => 'Home',
    'profile'                   => 'Profile',
    'dashboard'                 => 'Dashboard',
    'logout'                    => 'Logout',
    'shipping'                  => 'Shipping',
    'payments'                  => 'Payments',
    'account'                   => 'Account',

    // Dashboard
    'Drafts'            => 'Drafts',
    'Processing'        => 'Processing',
    'Delivered'         => 'Delivered',
    'Returned'          => 'Returned',
    'Percentage'        => 'Percentage',
];
